package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Headphone extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.headphones_activity);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Наушники");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(Headphone.this, MainActivity.class);
                Headphone.this.startActivity(switcher);

            }
        });


        Button buttonMoreAirpods = findViewById(R.id.buttonAirpodsMore);
        buttonMoreAirpods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/17a9ef1716404e77/naushniki-i-garnitury/?stock=now-today-tomorrow-later-out_of_stock&f[b74m]=9zmz1"));
                startActivity(intent);
            }
        });

        Button buttonJA = findViewById(R.id.buttonHJA);
        buttonJA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Headphone.this, ProductInfo.class);
                intent.putExtra("name", "JBL Wave 100");
                intent.putExtra("price", "3499 руб.");
                intent.putExtra("img", R.drawable.jbl_wave_100);
                intent.putExtra("src", "https://www.dns-shop.ru/product/a0b97424db082ff2/nausniki-tws-jbl-wave-100tws-cernyj/");
                intent.putExtra("description", "Наушники TWS JBL WAVE 100TWS примечательны классическим оформлением в черном цвете, эргономичным дизайном, технологичностью и продолжительной автономностью. Закрытое акустическое исполнение и динамики 8 мм при поддержке технологии JBL Deep Bass Sound обеспечивают насыщенное детализированное звучание. Интегрированный микрофон отвечает за четкость голосовой связи в процессе общения.\n" +
                        "Мягкие вкладыши способствуют комфортному размещению наушников в слуховом канале. JBL WAVE 100TWS работают без проводов на основе встроенного аккумулятора, который демонстрирует около 5 часов автономности. Зарядная станция помогает выполнить несколько полноценных зарядок и предлагает дополнительно 15 часов автономности. Из других особенностей JBL WAVE 100TWS отмечаются монорежим, световой индикатор состояния и голосовое управление.");
                startActivity(intent);
            }
        });
        Button buttonSA = findViewById(R.id.buttonHSA);
        buttonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Headphone.this, ProductInfo.class);
                intent.putExtra("name", "Samsung Galaxy Buds Live");
                intent.putExtra("price", "6999 руб.");
                intent.putExtra("img", R.drawable.samsung_galaxy_buds_live);
                intent.putExtra("src", "https://www.dns-shop.ru/product/2fd4d3ed00f6ed20/nausniki-tws-samsung-galaxy-buds-live-cernyj/");
                intent.putExtra("description", "Наушники TWS Samsung Galaxy Buds Live – это полностью беспроводная модель, созвучная с активным ритмом жизни. Гарнитура стала обладательницей уникальной формы, которая вместе с конструкцией-вкладышами гарантирует комфортную посадку в ушах и возможность использования часами напролет. За счет классической черной расцветки наушники выглядят элегантно и хорошо сочетаются с любым образом. Закрытое акустическое оформление и система активного шумоподавления способствуют хорошей звукоизоляции слушателя от посторонних шумов.\n" +
                        "Наушники TWS Samsung Galaxy Buds Live получили функционал гарнитуры за счет встроенного микрофона, который позволит отвечать на входящие звонки без необходимости доставать смартфон из кармана. Подключение к мобильному устройству посредством технологии Bluetooth 5.0 обеспечивает стабильную передачу сигнала без задержек и радиус действия 10 м. В каждом наушнике есть аккумулятор с емкостью 60 мАч, рассчитанный на 8 часов непрерывной работы. Ресурс зарядного кейса способен продлить прослушивание любимого плейлиста еще на 29 часов.");
                startActivity(intent);
            }
        });
        Button buttonNA = findViewById(R.id.buttonHAA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Headphone.this, ProductInfo.class);
                intent.putExtra("name", "Apple Airpods 2");
                intent.putExtra("price", "10999 руб.");
                intent.putExtra("img", R.drawable.airpods_2);
                intent.putExtra("src", "https://www.dns-shop.ru/product/abd952e8dcd0ed20/nausniki-tws-apple-airpods-2-belyj/");
                intent.putExtra("description", "Наушники TWS Apple Airpods 2 – фирменное устройство для техники одноименного бренда, обеспечивающее превосходным качеством звука с объемностью и сбалансированными частотами. Особенностью этой модели является длительная автономная работа как в режиме прослушивания музыки, так и в режиме разговора. Все благодаря хорошей емкости самих наушников и зарядного кейса, гарантирующих в сумме до 29 часов непрерывного функционирования. Двойной микрофон в конструкции устройства способствует четкой передаче вашего голоса во время телефонных разговоров.\n" +
                        "Наушники TWS Apple Airpods 2 поддерживают активацию помощника Siri при помощи голоса. Технология Bluetooth 5.0 обеспечивает беспроблемное и моментальное подключение к мобильному устройству, стабильную передачу аудиосигнала без задержек и радиус действия 10 метров. Динамические излучатели (по одному в каждом наушнике) отвечают за воспроизведение качественного звука независимо от того, музыку какого жанра вы предпочитаете. Пластиковые вкладыши с фирменным дизайном комфортно сидят в ушах.");
                startActivity(intent);
            }
        });
    }
}
