package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class NoteBook extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notebooks_activity);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Ноутбуки");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(NoteBook.this, MainActivity.class);
                NoteBook.this.startActivity(switcher);
            }
        });


        Button buttonMoreMac = findViewById(R.id.buttonMacMore);
        buttonMoreMac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/17a892f816404e77/noutbuki/?stock=now-today-tomorrow-later-out_of_stock&p=1"));
                startActivity(intent);
            }
        });


        Button buttonHA = findViewById(R.id.buttonWUA);
        buttonHA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NoteBook.this, ProductInfo.class);
                intent.putExtra("name", "HP 255 G8");
                intent.putExtra("price", "19999 руб.");
                intent.putExtra("img", R.drawable.hp_255_g8);
                intent.putExtra("src", "https://www.dns-shop.ru/product/f0c48e737060ed20/156-noutbuk-hp-255-g8-serebristyj/");
                intent.putExtra("description", "Ноутбук HP 255 G8 – универсальное решение для работы и учебы. Он сочетает в себе элегантный стиль, компактные габариты и производительность, необходимую для стабильной работы в различных программах. Аппаратная конфигурация представлена процессором AMD Athlon Gold 3150U, 4 ГБ оперативной памяти и накопителем HDD емкостью 1000 ГБ.\n" +
                        "На экране 15.6 дюймов формата HD с матовой поверхностью отображается реалистичная картинка без бликов. Для удобства работы в программах установлены полноразмерная клавиатура с цифровым блоком и тачпад. С боковых сторон портативного компьютера расположены порты и разъемы для внешних устройств: USB, HDMI, LAN. Дополнительно реализованы технологии беспроводной синхронизации Wi-Fi и Bluetooth. Литий-ионный аккумулятор 3615 мА*ч гарантирует продолжительную автономность HP 255 G8.");
                startActivity(intent);
            }
        });
        Button buttonSA = findViewById(R.id.buttonWSA);
        buttonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NoteBook.this, ProductInfo.class);
                intent.putExtra("name", "Acer Aspire 3 A314-22-R46L");
                intent.putExtra("price", "29999 руб.");
                intent.putExtra("img", R.drawable.acer_aspire_3_a314_22_r46l);
                intent.putExtra("src", "https://www.dns-shop.ru/product/cb2a034832d7ed20/14-noutbuk-acer-aspire-3-a314-22-r46l-cernyj/");
                intent.putExtra("description", "Ноутбук HP 255 G8 – универсальное решение для работы и учебы. Он сочетает в себе элегантный стиль, компактные габариты и производительность, необходимую для стабильной работы в различных программах. Аппаратная конфигурация представлена процессором AMD Athlon Gold 3150U, 4 ГБ оперативной памяти и накопителем HDD емкостью 1000 ГБ.\n" +
                        "На экране 15.6 дюймов формата HD с матовой поверхностью отображается реалистичная картинка без бликов. Для удобства работы в программах установлены полноразмерная клавиатура с цифровым блоком и тачпад. С боковых сторон портативного компьютера расположены порты и разъемы для внешних устройств: USB, HDMI, LAN. Дополнительно реализованы технологии беспроводной синхронизации Wi-Fi и Bluetooth. Литий-ионный аккумулятор 3615 мА*ч гарантирует продолжительную автономность HP 255 G8.");
                startActivity(intent);
            }
        });
        Button buttonNA = findViewById(R.id.buttonWAA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NoteBook.this, ProductInfo.class);
                intent.putExtra("name", "MacBook Air M1 2021");
                intent.putExtra("price", "74299 руб.");
                intent.putExtra("img", R.drawable.macbookairmone);
                intent.putExtra("src", "https://www.dns-shop.ru/product/5153a3e023db3332/133-noutbuk-apple-macbook-air-serebristyj/");
                intent.putExtra("description", "Ноутбук Apple MacBook Air имеет малый вес и тонкий корпус, что обеспечивает комфортные условия эксплуатации. Модель диагональю 13.3 дюйма оптимальна для общения в интернете, игр, работы в графических или текстовых программах. Устройство работает на базе macOS и поддерживает большое количество приложений.\n" +
                        "Ноутбук Apple MacBook Air работает бесшумно и характеризуется повышенной производительностью и скоростью. За бесперебойную работу отвечает 8-ядерный процессор и 8 ГБ оперативной памяти. Клавиатура имеет удобную раскладку и подсветку, что облегчает использование в вечернее время. Благодаря разрешению экрана 2560х1600 пикселей, изображения отличаются глубиной цветов и контрастностью. Корпус с глянцевым покрытием изготовлен из экологичного алюминия. Модель способна работать в течение продолжительного периода без подзарядки.");
                startActivity(intent);
            }
        });

    }
}
