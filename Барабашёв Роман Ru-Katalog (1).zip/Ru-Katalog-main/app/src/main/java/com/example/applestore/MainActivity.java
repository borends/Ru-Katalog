package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonMac = findViewById(R.id.buttonmainmac);
        buttonMac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mac = new Intent(MainActivity.this, NoteBook.class);
                MainActivity.this.startActivity(mac);
            }
        });


        Button buttonIpad = findViewById(R.id.buttonMainIpad);
        buttonIpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ipad = new Intent(MainActivity.this, Pads.class);
                MainActivity.this.startActivity(ipad);

            }
        });


        Button buttonIphone = findViewById(R.id.buttonMainIphone);
        buttonIphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent iphone = new Intent(MainActivity.this, Phone.class);
                startActivity(iphone);
            }
        });


        Button buttonWatch = findViewById(R.id.buttonMainWatch);
        buttonWatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent watch = new Intent(MainActivity.this, Watch.class);
                MainActivity.this.startActivity(watch);
            }
        });

        Button buttonAirpods = findViewById(R.id.buttonmainairpods);
        buttonAirpods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent airpods = new Intent(MainActivity.this, Headphone.class);
                MainActivity.this.startActivity(airpods);
            }
        });

        Button buttonConsoles = findViewById(R.id.buttonmainconsole);
        buttonConsoles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent console = new Intent(MainActivity.this, Consoles.class);
                MainActivity.this.startActivity(console);
            }
        });


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Ru-Katalog");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);

    }
}
