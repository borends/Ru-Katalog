package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Phone extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phone_activity);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Смартфоны");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(Phone.this, MainActivity.class);
                Phone.this.startActivity(switcher);
            }
        });

        Button buttonMoreIphone = findViewById(R.id.buttonIphoneMore);
        buttonMoreIphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/17a8a01d16404e77/smartfony/?stock=now-today-tomorrow-later-out_of_stock&p=1"));
                startActivity(intent);
            }
        });


        Button buttonJA = findViewById(R.id.buttonWUA);
        buttonJA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Phone.this, ProductInfo.class);
                intent.putExtra("name", "Samsung Galaxy M12");
                intent.putExtra("price", "11499 руб.");
                intent.putExtra("img", R.drawable.samsung_galaxy_m12);
                intent.putExtra("src", "https://www.dns-shop.ru/product/7a6f208b03b85cff/65-smartfon-samsung-galaxy-m12-32-gb-cernyj/");
                intent.putExtra("description", "Смартфон Samsung Galaxy M12 – достойный ассистент при организации досуга, общении в мессенджерах и оперативном решении важных задач. Высокая скорость реакции на команды пользователя достигается процессором Exynos 850, архитектура которого включает в себя 8 ядер. Прикоснувшись к боковой стенке корпуса, вы запустите процесс идентификации по отпечатку пальца.\n" +
                        "Смартфон Samsung Galaxy M12 оборудован широким 6.5-дюймовым дисплеем, сконструированным по технологии PLS. Она не допускает мерцания при трансляции роликов и гарантирует своевременную смену кадров. Не отказывайтесь от удовольствия сделать памятный кадр при слабом освещении. Светодиодная вспышка и 4 модуля помогают основной камере усиливать яркость и запечатлевать удаленные объекты без понижения резкости.");
                startActivity(intent);
            }
        });
        Button buttonSA = findViewById(R.id.buttonWSA);
        buttonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Phone.this, ProductInfo.class);
                intent.putExtra("name", "Honor X9a");
                intent.putExtra("price", "24999 руб.");
                intent.putExtra("img", R.drawable.honor_x9a);
                intent.putExtra("src", "https://www.dns-shop.ru/product/12b861f9e51535d9/667-smartfon-honor-x9a-128-gb-goluboj/");
                intent.putExtra("description", "Смартфон HONOR X9a 128 ГБ отличается поддержкой двух карт SIM и широкими функциональными возможностями. Он выполнен в тонком и компактном корпусе голубого цвета. Смартфон оснащен дисплеем 6.67 дюйма OLED высокого разрешения. Высокая производительность обеспечивается благодаря процессору Snapdragon 695 и 6 ГБ оперативной памяти.\n" +
                        "Основная камера 64+5+2 Мп с автофокусом и вспышкой способна делать реалистичные снимки в различных режимах и условиях. Камера 16 Мп позволяет создавать селфи или общаться по видеосвязи. В HONOR X9a реализованы востребованные беспроводные интерфейсы Wi-Fi и Bluetooth. Аккумулятор 5100 мА*ч гарантирует длительную автономность и поддерживает стандарт ускоренной зарядки.");
                startActivity(intent);
            }
        });
        Button buttonNA = findViewById(R.id.buttonWAA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Phone.this, ProductInfo.class);
                intent.putExtra("name", "Apple iPad Mini 6");
                intent.putExtra("price", "156399 руб.");
                intent.putExtra("img", R.drawable.iphone14pro);
                intent.putExtra("src", "https://www.dns-shop.ru/product/404be7514dcded20/61-smartfon-apple-iphone-14-pro-1000-gb-fioletovyj/");
                intent.putExtra("description", "У iPhone 14 Pro 6,1--дюймовая панель. Пиковая яркость — 2000 нит. Используется небольшой вырез с датчиком фронтальной камеры и системой Face ID. Кроме того, он способен визуально уменьшаться и увеличиваться. Предусмотрен режим Always-on Display (экран всегда включен).\n" +
                        "Аппаратная основа — A16 Bionic. Это 4-нм SoC с производительным GPU и дополнительным процессором Image Signal Proccessor для повышения качества снимков.\n" +
                        "Тыльная камера iPhone 14 Pro тройная, на 48, 12 и 12 Мп. Ночью iPhone 14 Pro снимает в два раза лучше, чем iPhone 13 Pro. Селфи-камера на 12 Мп.");
                startActivity(intent);
            }
        });
    }
}
