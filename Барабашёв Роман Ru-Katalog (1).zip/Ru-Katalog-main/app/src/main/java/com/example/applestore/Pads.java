package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Pads extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pad_activity);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Планшеты");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(Pads.this, MainActivity.class);
                Pads.this.startActivity(switcher);
            }
        });

        Button buttonMoreIpad = findViewById(R.id.buttonIpadMore);
        buttonMoreIpad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/17a8a05316404e77/planshety/?stock=now-today-tomorrow-later-out_of_stock&p=1"));
                startActivity(intent);
            }
        });



        Button buttonJA = findViewById(R.id.buttonPSA);
        buttonJA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Pads.this, ProductInfo.class);
                intent.putExtra("name", "Samsung Galaxy Tab A7 Lite");
                intent.putExtra("price", "13999 руб.");
                intent.putExtra("img", R.drawable.samsung_galaxy_tab_a7_lite);
                intent.putExtra("src", "https://www.dns-shop.ru/product/b2f5c0061938ed20/87-planset-samsung-galaxy-tab-a7-lite-wi-fi-32-gb-seryj/");
                intent.putExtra("description", "Планшет Samsung Galaxy Tab A7 Lite Wi-Fi 32 ГБ поможет эффективно и комфортно решать разные задачи дома, на работе и учебе, в поездках. Он выполнен в стильном и тонком металлическом корпусе серого цвета. Быстродействие системы обеспечивается благодаря процессору MediaTek Helio P22T и 3 ГБ памяти ОЗУ. В планшете установлен сенсорный экран 8.7 дюйма PLS 1340x800 пикселей с реалистичной картинкой. Динамики с технологией Dolby Atmos воспроизводят насыщенный звук.\n" +
                        "Samsung Galaxy Tab A7 Lite оснащен стандартами беспроводной коммуникации Wi-Fi и Bluetooth, портом USB Type-C и разъемом аудио 3.5 мм. Камера 8 Мп с автофокусом позволяет делать детализированные фото и видео. На передней стороне расположена камера 2 Мп. Аккумулятор 5100 мА*ч гарантирует продолжительное время автономности и отличается поддержкой ускоренной зарядки.");
                startActivity(intent);
            }
        });
        Button buttonSA = findViewById(R.id.buttonPHA);
        buttonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Pads.this, ProductInfo.class);
                intent.putExtra("name", "Honor Pad 8");
                intent.putExtra("price", "20999 руб.");
                intent.putExtra("img", R.drawable.honor_pad_8);
                intent.putExtra("src", "https://www.dns-shop.ru/product/fab42cb49bb9ed20/12-planset-honor-pad-8-wi-fi-128-gb-sinij/");
                intent.putExtra("description", "Планшет HONOR Pad 8 Wi-Fi 128 ГБ выполнен в металлическом корпусе с элегантной расцветкой. Он оборудован экраном 12 дюйма IPS 2000x1200 пикселей, на котором отображается четкая и красочная картинка. Передняя камера 5 Мп предназначена для селфи и видеозвонков. Основная камера 5 Мп позволяет делать реалистичные фотографии и видео. Расположенные в планшете 8 динамиков формируют чистый звук с пространственным эффектом.\n" +
                        "Планшетный компьютер работает под управлением ОС Android 12 с фирменной оболочкой Magic UI 6.1. Высокая производительность системы обеспечивается благодаря процессору Qualcomm Snapdragon 680 и 6 ГБ оперативной памяти. В HONOR Pad 8 реализованы технологии Wi-Fi и Bluetooth, порт USB Type-C. Аккумулятор 7250 мА*ч гарантирует длительную автономность и поддерживает функцию быстрой зарядки.");
                startActivity(intent);
            }
        });
        Button buttonNA = findViewById(R.id.buttonPAA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Pads.this, ProductInfo.class);
                intent.putExtra("name", "Apple iPad Mini 6");
                intent.putExtra("price", "68999 руб.");
                intent.putExtra("img", R.drawable.ipadmini62021);
                intent.putExtra("src", "https://www.dns-shop.ru/product/163be9b7dc01ed20/83-planset-apple-ipad-mini-2021-wi-fi-64-gb-seryj/");
                intent.putExtra("description", "Планшет Apple iPad mini (2021) Wi-Fi 64 ГБ с дисплеем 8.3 дюйма и тонким корпусом позволит с комфортом справляться с различными задачами. Панель IPS (2266x1488 пикселей) обеспечивает передачу реалистичного изображения. За быстродействие системы отвечают процессор A15 Bionic и 4 ГБ оперативной памяти.\n" +
                                "Камеры с датчиками 12 Мп способны создавать детализированные снимки в любых условиях освещенности. Из функциональных особенностей Apple iPad mini (2021) отмечаются сканер отпечатков пальцев, бесконтактная оплата Apple Pay, технология определения местоположения iBeacon, голосовой помощник Siri. Аккумулятор емкостью 5177 мА*ч гарантирует длительное время автономной работы и отличается поддержкой ускоренной зарядки. С помощью стилуса Apple Pencil можно рисовать, делать записи и заметки в документах.");
                startActivity(intent);
            }
        });


    }
}
