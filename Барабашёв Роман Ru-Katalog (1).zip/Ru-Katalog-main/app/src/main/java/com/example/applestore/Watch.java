package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Watch extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.watch_activity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Смарт-Часы");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(Watch.this, MainActivity.class);
                Watch.this.startActivity(switcher);
            }
        });


        Button buttonMoreWatch = findViewById(R.id.buttonWatchMore);
        buttonMoreWatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/251c82c88ed24e77/smart-chasy-i-braslety/?stock=now-today-tomorrow-later-out_of_stock&p=1"));
                startActivity(intent);
            }
        });




        Button buttonJA = findViewById(R.id.buttonWUA);
        buttonJA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Watch.this, ProductInfo.class);
                intent.putExtra("name", "Apple Watch Ultra 49mm");
                intent.putExtra("price", "73599 руб.");
                intent.putExtra("img", R.drawable.applewatch8ultra);
                intent.putExtra("src", "https://www.dns-shop.ru/product/48abadae5b24ed20/smart-casy-apple-watch-ultra-49mm/");
                intent.putExtra("description", "Смарт-часы Apple Watch Ultra 49mm в бежевом титановом корпусе оснащены сапфировым стеклом для защиты экрана от царапин и потертостей. Оранжевый ремешок добавляет ярких красок вашему образу, удобно облегает запястье и не мешает при занятиях спортом. Колесико Digital Crown упрощает навигацию по меню. Надписи и уведомления легко читаются на ярком сенсорном дисплее с разрешением 410x502 dpi.\n" +
                        "Apple Watch Ultra 49mm постоянно отслеживают пульс, температуру тела и уровень кислорода в крови, умеют делать ЭКГ. Синхронизация со смартфоном позволяет просматривать на дисплее уведомления от приложений, о звонках и SMS. Смарт-часы дополнены картами и навигацией, функциями SOS, обнаружения аварии и падения, смены дизайна циферблата.");
                startActivity(intent);
            }
        });
        Button buttonSA = findViewById(R.id.buttonWSA);
        buttonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Watch.this, ProductInfo.class);
                intent.putExtra("name", "Samsung Galaxy Watch4 Classic 46mm");
                intent.putExtra("price", "17099 руб.");
                intent.putExtra("img", R.drawable.samsung_galaxy_watch4);
                intent.putExtra("src", "https://www.dns-shop.ru/product/0875c8d0f4fdc823/smart-casy-samsung-galaxy-watch4-classic-46mm/");
                intent.putExtra("description", "Планшет HONOR Pad 8 Wi-Fi 128 ГБ выполнен в металлическом корпусе с элегантной расцветкой. Он оборудован экраном 12 дюйма IPS 2000x1200 пикселей, на котором отображается четкая и красочная картинка. Передняя камера 5 Мп предназначена для селфи и видеозвонков. Основная камера 5 Мп позволяет делать реалистичные фотографии и видео. Расположенные в планшете 8 динамиков формируют чистый звук с пространственным эффектом.\n" +
                        "Планшетный компьютер работает под управлением ОС Android 12 с фирменной оболочкой Magic UI 6.1. Высокая производительность системы обеспечивается благодаря процессору Qualcomm Snapdragon 680 и 6 ГБ оперативной памяти. В HONOR Pad 8 реализованы технологии Wi-Fi и Bluetooth, порт USB Type-C. Аккумулятор 7250 мА*ч гарантирует длительную автономность и поддерживает функцию быстрой зарядки.");
                startActivity(intent);
            }
        });
        Button buttonNA = findViewById(R.id.buttonWAA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Watch.this, ProductInfo.class);
                intent.putExtra("name", "Apple Apple Watch 7 45mm");
                intent.putExtra("price", "34499 руб.");
                intent.putExtra("img", R.drawable.apple_watch_7);
                intent.putExtra("src", "https://www.dns-shop.ru/product/0875c8d0f4fdc823/smart-casy-samsung-galaxy-watch4-classic-46mm/");
                intent.putExtra("description", "Смарт-часы Samsung Galaxy Watch4 Classic 46mm со стильным черным корпусом хорошо смотрятся на мужской и женской руке. Круглый цветной дисплей не боится царапин и ударов благодаря защитному стеклу Corning Gorilla Glass DX+, а сам корпус обладает водонепроницаемостью 5 Бар. Вы можете менять дизайн циферблата и настраивать уведомления даже на заблокированном экране.\n" +
                                "Набор датчиков помогает часам Samsung Galaxy Watch4 Classic 46mm постоянно измерять пульс, давление и другие показатели здоровья, высчитывать шаги и калории, следить за длительностью и качеством сна. Устройство умеет распознавать наличие храпа, выполнять ЭКГ и БИА. С его помощью можно управлять камерой и музыкой на смартфоне, принимать звонки и получать важные сообщения.");
                startActivity(intent);
            }
        });


    }
}
