package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Consoles extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.console_activity);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Игровые консоли");
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(Consoles.this, MainActivity.class);
                Consoles.this.startActivity(switcher);
            }
        });


        Button buttonConsolesMore = findViewById(R.id.buttonConsolesMore);
        buttonConsolesMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dns-shop.ru/catalog/00f7d5bb3ba87fd7/konsoli-i-videoigry/"));
                startActivity(intent);
            }
        });



        Button buttonNA = findViewById(R.id.buttonCNA);
        buttonNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Consoles.this, ProductInfo.class);
                intent.putExtra("name", "Nintendo Switch 32gb");
                intent.putExtra("price", "26999 руб.");
                intent.putExtra("img", R.drawable.nintendo_switch);
                intent.putExtra("src", "https://www.dns-shop.ru/product/6938f191e7a6ed20/igrovaa-konsol-nintendo-switch/");
                intent.putExtra("description", "Игровая приставка Nintendo Switch – компактное устройство, которое можно повсеместно брать с собой. Это портативное суперустройство оснащено также 2 геймпадами. При подключении к телевизору модель способна поддерживать разрешение уровнем до Full HD. Встроенная память модели в 32 ГБ сочетается с графическим ядром модели NVIDIA Tegra X1, процессором ARM Cortex A57 и оперативной памятью в 4 ГБ. Гибридный корпус Nintendo Switch имеет внешний блок питания. Разрешение его LCD-экрана диагональю 6.2 дюйма составляет 1280x720. Вес консоли – чуть меньше 300 г.");
                startActivity(intent);
            }
        });

        Button buttonXA = findViewById(R.id.buttonCXA);
        buttonXA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Consoles.this, ProductInfo.class);
                intent.putExtra("name", "Xbox Series X");
                intent.putExtra("price", "46999 руб.");
                intent.putExtra("img", R.drawable.xbox_series_x);
                intent.putExtra("src", "https://www.dns-shop.ru/product/de3881f3d7dfed20/igrovaa-konsol-microsoft-xbox-series-x/");
                intent.putExtra("description", "Игровая консоль Microsoft Xbox Series X способна впечатлять минимальным временем загрузки и завораживающими визуальными эффектами при воспроизведении игр с частотой до 120 кадров в секунду. Благодаря процессору AMD Zen 2 с частотой 3.8 ГГц и 16 ГБ оперативной памяти обеспечивается быстродействие системы. Внутреннее хранилище представлено накопителем емкостью 1 ТБ. Коммуникационные возможности Microsoft Xbox Series X реализованы технологией Wi-Fi, тремя портами USB 3.1, видеовыходом HDMI. В комплекте с игровой консолью поставляется фирменный беспроводной контроллер.");
                startActivity(intent);
            }
        });

        Button buttonPA = findViewById(R.id.buttonCPA);
        buttonPA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Consoles.this, ProductInfo.class);
                intent.putExtra("name", "Playstation 5");
                intent.putExtra("price", "58799 руб.");
                intent.putExtra("img", R.drawable.playstation_5);
                intent.putExtra("src", "https://www.dns-shop.ru/product/2645e72c6fca1b80/igrovaa-konsol-playstation-5/");
                intent.putExtra("description", "Испытайте мощь ЦП, графического процессора и SSD с особой встроенной системой ввода и вывода, которые переворачивают представления о возможностях PlayStation. Специальная интегрированная система ввода и вывода на консоли PS5 позволяет разработчикам получать данные с накопителя SSD настолько быстро, что перед создателями игр открываются недостижимые раньше возможности. Испытайте полное погружение в невероятно реалистичные миры благодаря специальным алгоритмам вычисления световых лучей, с которыми избранные игры PS5 заиграют красками света, тени и отражений.\n" +
                        "Наслаждайтесь плавным изображением на мониторах 4K во время игры с частотой кадров до 120 fps для игр с поддержкой частоты обновления 120 Гц. При подключении к телевизорам с HDR картинка игр PS5 с поддержкой этой технологии станет невероятно реалистичной с живыми, яркими цветами. Консоль PS5 поддерживает вывод сигнала 8K, чтобы в игры можно было играть на экранах с разрешением 4320p.\n" +
                        "Погрузитесь в мир объемного звука, где вы постоянно ощущаете себя в центре звуковой сцены и каждый звук направлен на вас. Благодаря технологии Tempest 3D AudioTech в поддерживаемых играх вы сможете насладиться трехмерным звучанием и в наушниках, и на динамиках телевизора. Испытайте реалистичную тактильную отдачу с беспроводным контроллером DualSense для некоторых игр PS5 с поддержкой этих функций и невероятный эффект полного погружения благодаря тактильным ощущениям в ответ на ваши действия и события в игре. Испытайте невероятные ощущения благодаря адаптивным спусковым кнопкам с динамически регулируемыми уровнями сопротивления, которые симулируют физические ощущения в ответ на ваши действия в поддерживаемых играх для PS5.");
                startActivity(intent);
            }
        });
    }
}
