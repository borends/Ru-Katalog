package com.example.applestore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ProductInfo extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_info_activity);




        Bundle arguments = getIntent().getExtras();
        String n = arguments.get("name").toString();
        String p = arguments.get("price").toString();
        String d = arguments.get("description").toString();
        String i = arguments.get("img").toString();
        String s = arguments.get("src").toString();


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(android.graphics.Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.arrowicon);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(ProductInfo.this, MainActivity.class);
                ProductInfo.this.startActivity(switcher);
            }
        });





        TextView productname = new TextView(this);
        productname = (TextView) findViewById(R.id.name);
        productname.setText(n);

        TextView productcost = new TextView(this);
        productcost = (TextView) findViewById(R.id.price);
        productcost.setText(p);

        TextView productdescription = new TextView(this);
        productdescription = (TextView) findViewById(R.id.about);
        productdescription.setText(d);

        ImageView prdimg = new ImageView(this);
        prdimg = (ImageView) findViewById(R.id.image);
        prdimg.setImageResource(Integer.parseInt(i));



        Button buttonBuy = findViewById(R.id.buttonBuy);
        buttonBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(s));
                startActivity(intent);
            }
        });


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switcher = new Intent(ProductInfo.this, MainActivity.class);
                ProductInfo.this.startActivity(switcher);
            }
        });



    }
}
